<?php
echo "
	<ul class='nav'>
		<li class='nav'><a href='index.php'>Home</a></li>
		<li class='nav'><a href='restaurant.php'>Restaurant</a></li>
		<li class='nav'><a href='reviews.php'>Reviews</a></li>
		<li class='nav'><a href='accommodation.php'>Accommodation</a></li>
		<li class='nav'><a href='beautyatthemill.php'>Beauty at The Mill</a></li>
   		<li class='nav'><a href='localarea.php'>Local Area</a></li>
   		<li class='nav'><a href='contactus.php'>Contact Us</a></li>
		<li class='nav'><a href='http://www.themillrestaurant.com/blog'>Blog</a></li>
	  </ul>
	  ";
?>