<?php
echo "<div id='footerLeftColumn'>
        <h3>Contact Us</h3>
        <p>Susan &amp; Derek Alcorn<br />
		The Mill Restaurant<br />
            Dunfanaghy<br />
            Co. Donegal<br />
            Ireland</p>
		<p>tel: +353 (0)74 913 6985</p>
        <p class='linkBack'>Web Design by <a href='http://www.marblemultimedia.com' target='_blank'>Marble Multimedia</a></p>
        </div>
        <div id='footerRightColumn'>
    	<a href='reviews.php'><img src='images/galleryImages/thumbnails/bridgestone2010.jpg' class='bordered' alt='Bridgestone Guide Logo' title='Bridgestone Guide Logo' /></a>
    	<a href='reviews.php'><img src='images/galleryImages/thumbnails/georginaCampbell.jpg' class='bordered' alt='Georgina Campbells Good Food Guide' title='Georgina Campbells Good Food Guide' /></a>
    	<a href='reviews.php'><img src='images/galleryImages/thumbnails/AS-LOGO.jpg' class='bordered' alt='Good Food Ireland Guide' title='Good Food Ireland' /></a>
        </div>
	  ";
?>